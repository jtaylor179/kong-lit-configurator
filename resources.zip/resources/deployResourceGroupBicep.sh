#az group create --name myResourceGroup --location eastus2
#https://learn.microsoft.com/en-us/cli/azure/deployment?view=azure-cli-latest#az-deployment-create
az deployment sub create --subscription MainSubscription --location eastus2 --template-file example2.bicep
